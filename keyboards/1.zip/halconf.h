#pragma once

#define HAL_USE_I2C TRUE

#include_next <halconf.h>
